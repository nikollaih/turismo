jQuery(document).ready(function($) {
	"use strict";
	try{
		$.removeCookie('cq_notify_close_cookie', {path: '/' });
	}catch(error){}
});
